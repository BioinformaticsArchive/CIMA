# Function:
#   Implement chemical-structure-informed metabolomics analysis (CIMA) strategy with a three-component regression normal mixture model (RNM);
#	Stochastic search variable selection (SSVS) is imposed on the summary molecular descriptors (SMD).

# Outputs:
#   'SMDs.posterior.inclusion.probabilities.csv': a data sheet that contains posterior inclusion probabilities for SMDs
#	'local.FDR.csv': a data sheet that contains estimated chemical-structure-informed local false discovery rates for metabolites
#	'loadings.SMDs.csv': a data sheet that contains loading vectors corresponding to the summarized SMDs from principal component analysis that reflect relative contributions of the MDs to the SMDs 
#	'WinBUGS_output': a folder that contains the original output from WinBUGS

# Libraries required:
#	R2WinBUGS

# Please cite the following article when using the package:
# Zhu, H. and Luo, M. (2013). Chemical structure informing statistical hypothesis testing in metabolomics. DOI: 10.1093/bioinformatics/btt708

CIMA <- function(test.statistics, p.values, MD.data, num.SMDs = 5, n.iter = 100000, n.burnin = 20000, n.thin = 10, debug = TRUE, bugs.directory)
{
	require(R2WinBUGS);
	num.metabolites <- length(p.values);
	
	# Full directory of WinBUGS code
	if(num.SMDs == 1){
		mfile <- paste(getwd(), "/RNM_WinBUGS_1.txt", sep = "");
	}else if((num.SMDs > 1)){
		mfile <- paste(getwd(), "/RNM_WinBUGS.txt", sep = "");
	}

	dir.output <- paste(getwd(), "/RNM_output", sep = "");
	dir.create(dir.output);
	dir.output.bugs <- paste(getwd(), "/RNM_output/WinBUGS_output", sep = "");
	dir.create(dir.output.bugs);
	
	# Summarize MDs into SMDs 
	MD.data <- apply(MD.data, 2, stand);
	loadings.SMDs <- as.matrix(eigen(cov(MD.data))$vectors[,1:min(num.SMDs, dim(MD.data)[2])]);
	SMD.data <- MD.data %*% loadings.SMDs;    
	SMD.data <- apply(SMD.data, 2, stand);
	num.SMDs <- dim(SMD.data)[2];
	colnames(loadings.SMDs) <- paste("SMD ", c(1:num.SMDs), sep = "");
	rownames(loadings.SMDs) <- paste("MD ", c(1:dim(MD.data)[2]), sep = "");
	write.csv(loadings.SMDs, paste(dir.output, "/loadings.SMDs.csv", sep = ""));

	# Obtain Z values
	p.values[which(p.values < 10^(-15))] <- 10^(-15);
	Z <- array(0,num.metabolites);
	Z[which(test.statistics < 0)] <- -qnorm(1 - p.values[which(test.statistics < 0)]/2);
	Z[which(test.statistics > 0)] <- qnorm(1 - p.values[which(test.statistics > 0)]/2);

	# Prepare inputs to the RNM model
	if(num.SMDs == 1){
		data <- list(m = num.metabolites, SMDdata = as.double(SMD.data), a = as.double(min(Z)), b = as.double(max(Z)), Z = as.double(Z));
	}else{
		data <- list(m = num.metabolites, numSMDs = num.SMDs, SMDdata = structure(.Data = as.double(SMD.data), .Dim = c(num.metabolites, num.SMDs)), a = as.double(min(Z)), b = as.double(max(Z)), Z = as.double(Z));
	}
	
	# Prepare initial values for the RNM model
	mu.init <- c(NA, -1, 1); # Means of normal mixture component densities
	tau.init <- c(1, 1, 1); # Precisions (1/variance) of normal mixture component densities
	C.init <- array(1, num.metabolites); # States of metabolites: 1: null  
	C.init[which(Z < (-1))] <- 2; # 2: negative non-null
	C.init[which(Z > 1)] <- 3; # 3: positive non-null
	SMDselection.init1 <- array(1, num.SMDs); # Selection indicators of SMDs: 1: not selected
	SMDselection.init2 <- array(2, num.SMDs); # 2: selected   
	inits1 <- list(mu = as.double(mu.init), tau = as.double(tau.init), C = as.integer(C.init), SMDselection1 = as.integer(SMDselection.init1), SMDselection2 = as.integer(SMDselection.init1));
	inits2 <- list(mu = as.double(mu.init), tau = as.double(tau.init), C = as.integer(C.init), SMDselection1 = as.integer(SMDselection.init2), SMDselection2 = as.integer(SMDselection.init2));

	# Run the RNM model
	output.RNM <- bugs(data = data, inits = list(inits1, inits2), parameters.to.save =c("mu", "tau", "SMDselection1", "SMDselection2", "C2", "C3"), model.file = mfile, n.chains = 2, n.iter = n.iter, n.burnin = n.burnin, n.thin = n.thin, debug = debug, bugs.directory = bugs.directory, working.directory = dir.output.bugs);

	# Output posterior inclusion probablities for SMDs 
	if(num.SMDs == 1){
		starting.index <- which(row.names(output.RNM$summary) == "SMDselection1");
	}else if((num.SMDs > 1)){
		starting.index <- which(row.names(output.RNM$summary) == "SMDselection1[1]");
	}
	SMDs.posterior.inclusion.probs <- output.RNM$summary[starting.index:(starting.index + num.SMDs - 1), 1]-1;
	if(num.SMDs == 1){
		starting.index <- which(row.names(output.RNM$summary) == "SMDselection2");
	}else if((num.SMDs > 1)){
		starting.index <- which(row.names(output.RNM$summary) == "SMDselection2[1]");
	}
	SMDs.posterior.inclusion.probs <- cbind(SMDs.posterior.inclusion.probs, output.RNM$summary[starting.index:(starting.index + num.SMDs - 1), 1] - 1);
	colnames(SMDs.posterior.inclusion.probs) <- c("Negative non-null vs. null", "Positive non-null vs null");
	rownames(SMDs.posterior.inclusion.probs) <- paste("SMD ", c(1:num.SMDs), sep = "");
	write.csv(SMDs.posterior.inclusion.probs, paste(dir.output, "/SMDs.posterior.inclusion.probabilities.csv", sep = ""));
	
	# Output chemical-structure-informed FDR
	starting.index <- which(row.names(output.RNM$summary) == "C2[1]");
	metabolites.posterior.prob.negative <- output.RNM$summary[starting.index:(starting.index + num.metabolites - 1), 1];
	starting.index <- which(row.names(output.RNM$summary) == "C3[1]");
	metabolites.posterior.prob.positive <- output.RNM$summary[starting.index:(starting.index + num.metabolites - 1), 1];
	local.FDR <- 1 - (metabolites.posterior.prob.negative > metabolites.posterior.prob.positive) * (metabolites.posterior.prob.negative)- (metabolites.posterior.prob.negative <= metabolites.posterior.prob.positive) * (metabolites.posterior.prob.positive);
	nonnull.state <- array("negative", num.metabolites);
	nonnull.state[which((metabolites.posterior.prob.negative - metabolites.posterior.prob.positive) <= 0)] <- "positive";
	local.FDR <- cbind(test.statistics, p.values, nonnull.state, local.FDR);
	rownames(local.FDR) <- paste("Metabolite ", c(1:num.metabolites), sep = "");
	write.csv(local.FDR, paste(dir.output, "/local.FDR.csv", sep = ""));
}

# Standardize a vector
stand<-function(v)  
{ 
   de <- sd(v) 
   if(de == 0) de <- 1
   (v - mean(v)) / de
}

















